
import React from 'react';

function App() {
  return (
    <div>
      <h1>SmartSDLC React Frontend</h1>
      <p>Welcome to the AI-powered SDLC system.</p>
    </div>
  );
}

export default App;
