# SmartSDLC – AI-Enhanced Software Development Lifecycle

This project includes:
- Flask backend (backend_flask/)
- FastAPI backend (backend_fastapi/)
- React frontend (frontend_react/)
- HTML/Bootstrap frontend (frontend_html/)

## How to Run

### Flask
```bash
cd backend_flask
pip install -r requirements.txt
python app.py
```

### FastAPI
```bash
cd backend_fastapi
pip install -r requirements.txt
uvicorn main:app --reload
```

### React Frontend
```bash
cd frontend_react
npm install
npm start
```

### HTML Frontend
Just open index.html in a browser from `frontend_html/`

---

All modules use mock AI logic simulating IBM Watsonx Granite-20B.

Developed as part of the SmartSDLC AI project.
