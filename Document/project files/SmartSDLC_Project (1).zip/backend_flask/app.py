
from flask import Flask, request, jsonify
app = Flask(__name__)

@app.route('/classify', methods=['POST'])
def classify():
    data = request.json.get("text", "")
    return jsonify({"phase": "Development", "text": data})

@app.route('/')
def home():
    return "SmartSDLC Flask Backend Running"

if __name__ == '__main__':
    app.run(debug=True)
