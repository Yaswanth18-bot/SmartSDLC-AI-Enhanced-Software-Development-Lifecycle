
from fastapi import FastAPI, Request
from pydantic import BaseModel

app = FastAPI()

class InputText(BaseModel):
    text: str

@app.post("/classify")
async def classify(input: InputText):
    return {"phase": "Testing", "text": input.text}

@app.get("/")
def read_root():
    return {"message": "SmartSDLC FastAPI Backend Running"}
